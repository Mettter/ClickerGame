import sqlite3

class PasswordDatabase:
    def __init__(self, dbname: str = "passwords.db") -> None:
        self.dbname = dbname

    def init_table(self) -> None:
        self.conn = sqlite3.connect(self.dbname)
        cursor = self.conn.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT NOT NULL UNIQUE,
                password TEXT NOT NULL
            )
        ''')
        self.conn.commit()
        self.conn.close()

    def get_users(self) -> list:
        self.cursor.execute("SELECT id, username, password FROM users")
        return self.cursor.fetchall()

    def insert_user(self, user: dict) -> None:
        self.cursor.execute(
            "INSERT INTO users (username, password) VALUES (?, ?)",
            (user['username'], user['password'])
        )

    def delete_user(self, username: str) -> None:
        self.cursor.execute("DELETE FROM users WHERE username = ?", (username,))

    def __enter__(self):
        self.init_table()
        self.conn = sqlite3.connect(self.dbname)
        self.cursor = self.conn.cursor()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self.conn:
            self.conn.commit()
            self.conn.close()
