from fastapi import FastAPI, HTTPException, requests
from pydantic import BaseModel
import hashlib
import pymysql
import cryptography
import random
import sys
import time
from PyQt5.QtCore import Qt, QTimer, QDateTime, QDate

from basewindow import ClickerGameWindow, AuthorithationWindow, SWindow
from PyQt5.QtWidgets import QApplication, QWidget, QVBoxLayout, QLineEdit, QPushButton, QLabel, QMessageBox, \
    QListWidget, QHBoxLayout, QComboBox, QMenu

from matplotlib import pyplot as plt
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas

from database import PasswordDatabase

app = FastAPI(
    title="My API",
    description="A simple FastAPI application",
    version="1.0.0"
)

@app.get("/")  # HTTP GET method at root path
async def root():
    return {"message": "Hello, World!"}

@app.post("/button-pressed")
async def button_pressed():  #async def can be used by many users at once
    print("Button was pressed!")
    return {"message": "Button press received"}

# with PasswordDatabase() as db:
#     pass

class authorithation(AuthorithationWindow):
    def __init__(self) -> None:
        super().__init__("Authorithation Window")
        layout = QVBoxLayout()
        self.setLayout(layout)
        self.password = ''
        layout.addLayout(self.init_at_layout())

    def init_at_layout(self):
        header_layout = QVBoxLayout()

        self.w_text = QLabel("Log in or Sign in")

        self.log_in = QPushButton("Log in")
        self.log_in.clicked.connect(self.open_second_window)

        self.sign_in = QPushButton("Sign in")
        self.sign_in.clicked.connect(self.open_regestration_window)

        header_layout.addWidget(self.w_text)
        header_layout.addWidget(self.log_in)
        header_layout.addWidget(self.sign_in)

        return header_layout

    def open_regestration_window(self):
        self.second_window = signInWindow("Sign in!")
        self.second_window.show()
        self.hide()

    def open_second_window(self):
        self.second_window = clickerGame("Clickerr!")  # <-- Use your game class
        self.second_window.show()
        self.hide()

class signInWindow(SWindow):
    def __init__(self, header) -> None:
        super().__init__(header)
        layout = QVBoxLayout()
        self.setLayout(layout)
        self.password = ''
        layout.addLayout(self.init_sw_layout())

    def init_sw_layout(self):
        header_layout = QVBoxLayout()
        self.s_text = QLabel("Create reliable password!")

        self.password_input_field = QLineEdit()
        self.password_input_field.setPlaceholderText("Type something here...")

        self.set_password = QPushButton("Set password")
        self.set_password.clicked.connect(self.set_password_def)

        header_layout.addWidget(self.s_text)
        header_layout.addWidget(self.password_input_field)
        header_layout.addWidget(self.set_password)

        return header_layout

    def set_password_def(self):
        password = self.password_input_field.text()
        with open("passwords.txt", "a") as file:  # Use "a" for append
            file.write(password + "\n")

class clickerGame(ClickerGameWindow):
    def __init__(self, header) -> None:
        super().__init__(header)
        layout = QVBoxLayout()
        self.setLayout(layout)
        self.c_p_c_upgrade_cost = 50
        self.l_r_amount = 0
        self.l_r_upgrade_cost = 250
        self.a_p_c_upgrade_cost = 100
        self.am_p_c_upgrade_cost = 500
        self.click_cooldown = 1
        self.coin_amount = 1
        self.coin_per_click = 1
        self.coin_per_auto = 1
        self.doAutoCoinAddition = True
        self.auto_coin_timer = QTimer(self)
        self.auto_coin_timer.timeout.connect(self.add_auto_coins)
        self.auto_click_cooldown = 5000
        self.auto_coin_timer.start(self.auto_click_cooldown)
        self.last_claimed_date = None
        layout.addLayout(self.init_main_layout())

    def init_main_layout(self):
        header_layout = QVBoxLayout()

        self.try_claim_daily_bonus_button = QPushButton(
            f"    Claim daily bonus!    ")
        self.try_claim_daily_bonus_button.setObjectName("tryClaimButton")
        self.try_claim_daily_bonus_button.clicked.connect(self.check_daily_bonus)

        self.auto_click_amount_upgrade_button = QPushButton(
            f"Click to buy auto click amount upgrade! Cost: {self.am_p_c_upgrade_cost}", self)
        self.auto_click_amount_upgrade_button.setObjectName("AMupgradeButton")
        self.auto_click_amount_upgrade_button.clicked.connect(self.am_p_c_upgrade)

        self.auto_click_upgrade_button = QPushButton(
            f"Click to buy auto click upgrade! Cost: {self.a_p_c_upgrade_cost}", self)
        self.auto_click_upgrade_button.setObjectName("AupgradeButton")
        self.auto_click_upgrade_button.clicked.connect(self.a_p_c_upgrade)

        self.lucky_roll_upgrade_button = QPushButton(f"Click to buy lucky roll upgrade! Cost: {self.l_r_upgrade_cost}", self)
        self.lucky_roll_upgrade_button.setObjectName("lupgradeButton")
        self.lucky_roll_upgrade_button.clicked.connect(self.l_r_upgrade)

        self.coins_per_click_upgrade_button = QPushButton(f"Click to buy coins per click upgrade! Cost: {self.c_p_c_upgrade_cost}", self)
        self.coins_per_click_upgrade_button.setObjectName("cupgradeButton")
        self.coins_per_click_upgrade_button.clicked.connect(self.c_p_c_upgrade)

        self.coin_count_display = QLineEdit(self)
        self.coin_count_display.setText(f"Coins you have: {self.coin_amount}")
        self.coin_count_display.setReadOnly(True)

        self.click_button = QPushButton("Click!", self)
        self.click_button.setObjectName("clickButton")
        self.click_button.clicked.connect(self.add_coins)

        header_layout.addWidget(self.try_claim_daily_bonus_button)
        header_layout.addWidget(self.auto_click_amount_upgrade_button)
        header_layout.addWidget(self.auto_click_upgrade_button)
        header_layout.addWidget(self.lucky_roll_upgrade_button)
        header_layout.addWidget(self.coins_per_click_upgrade_button)
        header_layout.addWidget(self.coin_count_display)
        header_layout.addWidget(self.click_button)

        return header_layout

    def add_coins(self):
        self.coin_amount += self.coin_per_click
        print(self.coin_amount)
        luckyRollProbability = random.random()
        if luckyRollProbability <= 0.05:
            self.coin_amount += self.coin_amount * self.l_r_amount
        self.coin_count_display.setText(f"Coins you have: {self.coin_amount}")

    from PyQt5.QtCore import QDate
    from PyQt5.QtWidgets import QMessageBox

    def check_daily_bonus(self):
        today = QDate.currentDate()

        try:
            with open("dailyBonusDate.txt", "r") as file:
                last_date_str = file.read().strip()
                if last_date_str:
                    self.last_claimed_date = QDate.fromString(last_date_str, "yyyy-MM-dd")
                else:
                    self.last_claimed_date = None
        except FileNotFoundError:
            self.last_claimed_date = None

        if self.last_claimed_date == today:
            QMessageBox.information(self, "Daily Bonus", "You already claimed your bonus today!")
            return

        self.coin_amount += 1000
        self.coin_count_display.setText(f"Coins you have: {self.coin_amount}")
        QMessageBox.information(self, "Daily Bonus", "You received 1000 coins!")

        with open("dailyBonusDate.txt", "w") as file:
            file.write(today.toString("yyyy-MM-dd"))

        self.last_claimed_date = today

    def on_button_click(self):
        try:
            response = requests.post("http://127.0.0.1:8000/button-pressed")
            data = response.json()
            QMessageBox.information(self, "Response", data.get("message", "No message"))
        except Exception as e:
            QMessageBox.warning(self, "Error", str())

    def add_auto_coins(self):
        self.coin_amount += self.coin_per_auto
        print(self.coin_amount)
        self.coin_count_display.setText(f"Coins you have: {self.coin_amount}")

    def c_p_c_upgrade(self):
        if self.coin_amount >= self.c_p_c_upgrade_cost:
            self.coin_per_click += 1
            self.coin_amount -= self.c_p_c_upgrade_cost
            self.coin_count_display.setText(f"Coins you have: {self.coin_amount}")
            self.c_p_c_upgrade_cost += int(self.c_p_c_upgrade_cost * 0.5)
            self.coins_per_click_upgrade_button.setText(f"Click to buy coins per click upgrade! Cost: {self.c_p_c_upgrade_cost}")
        else:
            QMessageBox.warning(
                self,
                "Not enough coins",
                "You don't have enough coins to buy this upgrade."
            )

    def a_p_c_upgrade(self):
        if self.coin_amount >= self.a_p_c_upgrade_cost:
            self.auto_click_cooldown -= 200
            self.auto_coin_timer.start(self.auto_click_cooldown)
            self.coin_amount -= self.a_p_c_upgrade_cost
            self.coin_count_display.setText(f"Coins you have: {self.coin_amount}")
            self.a_p_c_upgrade_cost += int(self.a_p_c_upgrade_cost * 0.5)
            self.auto_click_upgrade_button.setText(f"Click to buy auto click upgrade! Cost: {self.a_p_c_upgrade_cost}")
            if self.auto_click_cooldown <= 10:
                self.auto_click_cooldown = 10
                self.auto_click_upgrade_button.setText(
                    f"You bought max auto click upgrades!")
                self.auto_click_upgrade_button.setEnabled(False)
        else:
            QMessageBox.warning(
                self,
                "Not enough coins",
                "You don't have enough coins to buy this upgrade."
            )

    def am_p_c_upgrade(self):
        if self.coin_amount >= self.am_p_c_upgrade_cost:
            self.coin_per_auto += 1
            self.coin_amount -= self.am_p_c_upgrade_cost
            self.coin_count_display.setText(f"Coins you have: {self.coin_amount}")
            self.am_p_c_upgrade_cost += int(self.am_p_c_upgrade_cost * 0.5)
            self.auto_click_amount_upgrade_button.setText(f"Click to buy coins per click upgrade! Cost: {self.am_p_c_upgrade_cost}")
        else:
            QMessageBox.warning(
                self,
                "Not enough coins",
                "You don't have enough coins to buy this upgrade."
            )

    def l_r_upgrade(self):
        if self.coin_amount >= self.l_r_upgrade_cost:
            self.l_r_amount += 1
            self.coin_amount -= self.l_r_upgrade_cost
            self.coin_count_display.setText(f"Coins you have: {self.coin_amount}")
            self.l_r_upgrade_cost += int(self.l_r_upgrade_cost * 2)
            self.lucky_roll_upgrade_button.setText(f"Click to buy lucky roll upgrade! Cost: {self.l_r_upgrade_cost}")
        else:
            QMessageBox.warning(
                self,
                "Not enough coins",
                "You don't have enough coins to buy this upgrade."
            )

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = authorithation()
    window.show()
    sys.exit(app.exec_())